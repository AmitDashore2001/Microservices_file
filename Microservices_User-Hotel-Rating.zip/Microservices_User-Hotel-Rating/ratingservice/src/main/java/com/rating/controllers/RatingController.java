package com.rating.controllers;


import com.rating.entity.Rating;
import com.rating.service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rating")
public class RatingController {

    @Autowired
    private RatingService ratingService;

    @PostMapping("/")
    public Rating createRating(@RequestBody Rating rating) {
        return this.ratingService.createRating(rating);

    }

    @GetMapping("/{id}")
    public Rating getRating(@PathVariable Long id) {
        return this.ratingService.getRating(id);
    }

    @GetMapping("/")
    public List<Rating> getAllRating() {
        return this.ratingService.getAllRating();
    }

    @GetMapping("/user/{userId}")
    public List<Rating> getRatingByUserId(@PathVariable String userId) {
     return this.ratingService.getRatingByUserId(userId);
    }
    @GetMapping("/hotel/{hotelId}")
    public List<Rating> getRatingByHotelId(@PathVariable String hotelId) {
        return this.ratingService.getRatingByUserId(hotelId);
    }
}
