package com.rating.service;

import com.rating.entity.Rating;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RatingService {

    public Rating createRating(Rating rating);
    public Rating getRating(Long id);
    public List<Rating> getAllRating();

    public List<Rating> getRatingByUserId(String userId);

    public List<Rating> getRatingByHotelId(String hotelId);

//    public Rating updateRating(Rating rating, Long id);
//    public Rating deleteRating(Long id);

}
