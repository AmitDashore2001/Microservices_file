package com.rating.dao;

import com.rating.entity.Rating;
import jakarta.persistence.Id;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RatingDao extends JpaRepository<Rating, Long> {

    public List<Rating> findByUserID(String userId);
    public List<Rating> findByHotelID(String hotelId);
}
