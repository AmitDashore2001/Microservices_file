package com.rating.service;

import com.rating.dao.RatingDao;
import com.rating.entity.Rating;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatingServiceImpl implements  RatingService {

    @Autowired
    private RatingDao ratingDao;

    @Override
    public Rating createRating(Rating rating) {
        return this.ratingDao.save(rating);
    }

    @Override
    public Rating getRating(Long id) {
        Rating r1 = this.ratingDao.findById(id).orElseGet(null);
        return r1;
    }

    @Override
    public List<Rating> getAllRating() {
        return this.ratingDao.findAll();
    }

    @Override
    public List<Rating> getRatingByUserId(String userId) {
        return this.ratingDao.findByUserID(userId);
    }
    @Override
    public List<Rating> getRatingByHotelId(String hotelId) {
        return this.ratingDao.findByHotelID(hotelId);
    }
}

//    @Override
//    public Rating updateRating(Rating rating, Long id) {
//        return null;
//    }
//
//    @Override
//    public Rating deleteRating(Long id) {
//        return null;
//    }
//}
