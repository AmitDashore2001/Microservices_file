package com.user.service;

import com.user.dao.UserDao;
import com.user.entity.User;
import com.user.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{

@Autowired
private UserDao userDao;

    @Override
    public User createUser(User user) {
        return this.userDao.save(user);
    }

    @Override
    public List<User> getAll() {
        return this.userDao.findAll();
    }

    @Override
    public User getById(long id) {
        User user = this.userDao.findById(id).orElseThrow(() -> new ResourceNotFoundException("User is not Found"));
        return user;
    }

    @Override
    public User updateUser(long id, User user) {
         User user1= this.userDao.findById(id).orElseThrow(()-> new ResourceNotFoundException(" This "+id+" User Id is not Present"));
               user1.setName(user.getName());
               user1.setEmail(user.getEmail());
               user1.setAbout(user.getAbout());
           return this.userDao.save(user1);
    }

    @Override
    public void deleteUsers(long id) {
        this.userDao.deleteById(id);
    }
}
