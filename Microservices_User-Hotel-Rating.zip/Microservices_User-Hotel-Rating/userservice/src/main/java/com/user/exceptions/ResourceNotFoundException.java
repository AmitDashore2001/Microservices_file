package com.user.exceptions;

public class ResourceNotFoundException extends RuntimeException{
       public ResourceNotFoundException(String message) {

           super(message);
       }
}
