package com.user.controller;

import com.user.entity.User;
import com.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/")
    public User createUser(@RequestBody User user){
    return this.userService.createUser(user);
    }

    @GetMapping("/")
    public List<User> getAllUser(){
        return this.userService.getAll();
    }

    @GetMapping("{userId}")
    public User getUserById(@PathVariable long userId ){
        return this.userService.getById(userId);
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable long id,@RequestBody User user)
    {
         return this.userService.updateUser(id,user);

    }
    @DeleteMapping("/{id}")
    public ResponseEntity deleteUser(@PathVariable long id){
        this.userService.deleteUsers(id);
        return ResponseEntity.ok("Deleted Successfully");
    }
}
