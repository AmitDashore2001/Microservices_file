package com.user.service;

import com.user.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService {

    public User createUser(User user);
    public List<User> getAll();
    public User getById(long id);
    public User updateUser(long id,User user);
    public void deleteUsers(long id);

}
