package com.hotel.service;

import com.hotel.entity.Hotel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface HotelService {

    public Hotel createHotel(Hotel hotel);
    public Hotel getHotelById(long id);
    public List<Hotel> getHotel();
    public Hotel updateHotel(Hotel hotel,long id);

    //    public void deleteHotel(long id);
}
