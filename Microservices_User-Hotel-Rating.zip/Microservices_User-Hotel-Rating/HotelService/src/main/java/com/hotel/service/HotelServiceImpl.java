package com.hotel.service;

import com.hotel.dao.HotelDao;
import com.hotel.entity.Hotel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelServiceImpl implements HotelService {
    @Autowired
    private HotelDao hotelDao;

    @Override
    public Hotel createHotel(Hotel hotel) {
        return this.hotelDao.save(hotel);
    }

    @Override
    public Hotel getHotelById(long id)
    {
        Hotel hotel = this.hotelDao.findById(id).orElse(null);
        return hotel;
    }

    @Override
    public List<Hotel> getHotel()
    {
        return this.hotelDao.findAll();
    }

    @Override
    public Hotel updateHotel(Hotel hotel, long id) {
        Hotel hotel1 = this.hotelDao.findById(id).orElse(null);
        hotel1.setName(hotel.getName());
        hotel1.setAbout(hotel.getAbout());
        hotel1.setLocation(hotel.getLocation());
        return this.hotelDao.save(hotel1);
    }
}
