package com.hotel.controller;

import com.hotel.entity.Hotel;
import com.hotel.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotel")
public class HotelController {

    @Autowired
    private HotelService hotelService;
    @PostMapping("/")
    public Hotel createHotel(@RequestBody Hotel hotel) {
        return this.hotelService.createHotel(hotel);
    }

    @GetMapping("/{id}")
    public Hotel getHotel(@PathVariable long id) {
        return this.hotelService.getHotelById(id);
    }

    @GetMapping("/")
    public List<Hotel> getAllHotels(){
       return this.hotelService.getHotel();
    }

    @PutMapping("/{id}")
    public Hotel updateHotel(@RequestBody Hotel hotel, @PathVariable long id){
        return this.hotelService.updateHotel(hotel,id);
    }


}
